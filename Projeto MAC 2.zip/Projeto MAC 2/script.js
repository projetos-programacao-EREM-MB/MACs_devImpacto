/* =====================================================
   PROJETO MAC
   Sistema de Login + Área do Aluno e Professor
===================================================== */


/* =====================================================
   DADOS
===================================================== */

const livros = [

    {
        titulo: "Recife Revolucionário",
        descricao: "Material relacionado à história e aos movimentos sociais de Recife.",
        materia: "História"
    },

    {
        titulo: "Entre Dois Mundos",
        descricao: "Livro para apoio às atividades de leitura e interpretação.",
        materia: "Literatura"
    },

    {
        titulo: "Labatruz",
        descricao: "Obra disponível para atividades escolares.",
        materia: "Literatura"
    },

    {
        titulo: "O Príncipe e o Mendigo",
        descricao: "Clássico da literatura para leitura e análise.",
        materia: "Literatura"
    },

    {
        titulo: "O Mundo de Sofia",
        descricao: "Introdução à filosofia através de uma narrativa.",
        materia: "Filosofia"
    },

    {
        titulo: "Inocência",
        descricao: "Obra literária brasileira para estudo.",
        materia: "Literatura"
    },

    {
        titulo: "Dom Casmurro",
        descricao: "Obra de Machado de Assis para estudo de Literatura.",
        materia: "Literatura"
    },

    {
        titulo: "Rotas de Fuga",
        descricao: "Material disponível para atividades escolares.",
        materia: "Literatura"
    }

];


let aulas = [

    {
        titulo: "Revolução Francesa",
        materia: "História",
        descricao:
            "Conteúdo introdutório sobre a Revolução Francesa e seus principais acontecimentos."
    },

    {
        titulo: "Introdução à Filosofia",
        materia: "Filosofia",
        descricao:
            "Conceitos básicos para compreender o pensamento filosófico."
    }

];


let videos = [

    {
        titulo: "Aula de História",
        materia: "História",
        link: "https://www.youtube.com/"
    }

];


/* =====================================================
   QUANDO A PÁGINA CARREGAR
===================================================== */

document.addEventListener("DOMContentLoaded", function () {

    const paginaAtual =
        window.location.pathname.split("/").pop();


    /* ---------------------------------------------
       LOGIN
    --------------------------------------------- */

    if (paginaAtual === "login.html" || paginaAtual === "") {

        const formLogin =
            document.getElementById("formLogin");


        if (formLogin) {

            formLogin.addEventListener(
                "submit",
                fazerLogin
            );

        }

        return;
    }


    /* ---------------------------------------------
       SITE
    --------------------------------------------- */

    configurarSite();

});


/* =====================================================
   LOGIN
===================================================== */

function fazerLogin(event) {

    event.preventDefault();


    const usuario =
        document
            .getElementById("usuario")
            .value
            .trim()
            .toLowerCase();


    const senha =
        document
            .getElementById("senha")
            .value;


    const tipo =
        document
            .getElementById("tipoUsuario")
            .value;


    const erro =
        document
            .getElementById("erroLogin");


    /* PROFESSOR */

    if (
        tipo === "professor" &&
        usuario === "professor" &&
        senha === "prof123"
    ) {

        localStorage.setItem(
            "mac_perfil",
            "professor"
        );

        window.location.href =
            "index.html";

        return;
    }


    /* ALUNO */

    if (
        tipo === "aluno" &&
        usuario === "aluno" &&
        senha === "aluno123"
    ) {

        localStorage.setItem(
            "mac_perfil",
            "aluno"
        );

        window.location.href =
            "index.html";

        return;
    }


    /* ERRO */

    erro.textContent =
        "Usuário, senha ou tipo de acesso incorreto.";

}


/* =====================================================
   CONFIGURAR SITE
===================================================== */

function configurarSite() {

    let perfil =
        localStorage.getItem("mac_perfil");


    /* Se entrar diretamente no index */

    if (!perfil) {

        window.location.href =
            "login.html";

        return;
    }


    configurarUsuario(perfil);

    carregarLivros();

    carregarAulas();

    carregarVideos();


    /* Professor pode publicar */

    const menuProfessor =
        document.getElementById("menuProfessor");


    if (perfil === "professor") {

        menuProfessor.classList.remove(
            "escondido"
        );

    } else {

        menuProfessor.classList.add(
            "escondido"
        );

    }


    mostrarPagina("inicio");

}


/* =====================================================
   USUÁRIO
===================================================== */

function configurarUsuario(perfil) {

    const nomePerfil =
        document.getElementById("nomePerfil");


    const tipoPerfil =
        document.getElementById("tipoPerfil");


    const tituloBoasVindas =
        document.getElementById("tituloBoasVindas");


    if (perfil === "professor") {

        nomePerfil.textContent =
            "Professor";

        tipoPerfil.textContent =
            "Professor";

        tituloBoasVindas.textContent =
            "Bem-vindo, professor!";

    } else {

        nomePerfil.textContent =
            "Aluno";

        tipoPerfil.textContent =
            "Aluno";

        tituloBoasVindas.textContent =
            "Bem-vindo ao Projeto MAC!";

    }

}


/* =====================================================
   TROCAR PÁGINA
===================================================== */

function mostrarPagina(pagina) {

    const paginas =
        document.querySelectorAll(".pagina");


    paginas.forEach(function (elemento) {

        elemento.classList.add(
            "escondido"
        );

    });


    const paginaEscolhida =
        document.getElementById(
            "pagina-" + pagina
        );


    if (paginaEscolhida) {

        paginaEscolhida.classList.remove(
            "escondido"
        );

    }


    const titulo =
        document.getElementById(
            "tituloPagina"
        );


    const titulos = {

        inicio: "Início",

        aulas: "Aulas",

        livros: "Biblioteca",

        videos: "Vídeos",

        publicar: "Publicar conteúdo"

    };


    titulo.textContent =
        titulos[pagina] || "Projeto MAC";

}


/* =====================================================
   LIVROS
===================================================== */

function carregarLivros() {

    const lista =
        document.getElementById(
            "listaLivros"
        );


    const inicio =
        document.getElementById(
            "listaLivrosInicio"
        );


    if (!lista || !inicio) {
        return;
    }


    lista.innerHTML = "";

    inicio.innerHTML = "";


    livros.forEach(function (livro) {

        const card =
            criarCardLivro(livro);


        lista.appendChild(card);


        const cardInicio =
            criarCardLivro(livro);


        inicio.appendChild(cardInicio);

    });

}


/* =====================================================
   CARD DO LIVRO
===================================================== */

function criarCardLivro(livro) {

    const card =
        document.createElement("article");


    card.className =
        "livro-card";


    card.innerHTML = `

        <div class="livro-capa">
            📖
        </div>

        <h3>
            ${livro.titulo}
        </h3>

        <p>
            ${livro.descricao}
        </p>

        <div class="livro-info">
            ${livro.materia}
            • Disponível
        </div>

    `;


    return card;

}


/* =====================================================
   AULAS
===================================================== */

function carregarAulas() {

    const lista =
        document.getElementById(
            "listaAulas"
        );


    if (!lista) {
        return;
    }


    lista.innerHTML = "";


    aulas.forEach(function (aula) {

        const card =
            document.createElement("article");


        card.className =
            "aula-card";


        card.innerHTML = `

            <h3>
                ${aula.titulo}
            </h3>

            <div class="materia">
                ${aula.materia}
            </div>

            <p>
                ${aula.descricao}
            </p>

        `;


        lista.appendChild(card);

    });

}


/* =====================================================
   VÍDEOS
===================================================== */

function carregarVideos() {

    const lista =
        document.getElementById(
            "listaVideos"
        );


    if (!lista) {
        return;
    }


    lista.innerHTML = "";


    videos.forEach(function (video) {

        const card =
            document.createElement("article");


        card.className =
            "video-card";


        card.innerHTML = `

            <h3>
                ${video.titulo}
            </h3>

            <p>
                ${video.materia}
            </p>

            <br>

            <a
                href="${video.link}"
                target="_blank"
            >
                ▶ Assistir no YouTube
            </a>

        `;


        lista.appendChild(card);

    });

}


/* =====================================================
   PUBLICAR AULA
===================================================== */

function publicarAula() {

    const titulo =
        document
            .getElementById("tituloAula")
            .value
            .trim();


    const materia =
        document
            .getElementById("materiaAula")
            .value
            .trim();


    const descricao =
        document
            .getElementById("descricaoAula")
            .value
            .trim();


    const video =
        document
            .getElementById("videoAula")
            .value
            .trim();


    const mensagem =
        document.getElementById(
            "mensagemPublicacao"
        );


    if (
        !titulo ||
        !materia ||
        !descricao
    ) {

        mensagem.textContent =
            "Preencha título, matéria e conteúdo.";

        return;
    }


    aulas.unshift({

        titulo: titulo,

        materia: materia,

        descricao: descricao

    });


    if (video) {

        videos.unshift({

            titulo: titulo,

            materia: materia,

            link: video

        });

    }


    carregarAulas();

    carregarVideos();


    mensagem.textContent =
        "Aula publicada com sucesso!";


    document
        .getElementById("tituloAula")
        .value = "";


    document
        .getElementById("materiaAula")
        .value = "";


    document
        .getElementById("descricaoAula")
        .value = "";


    document
        .getElementById("videoAula")
        .value = "";

}


/* =====================================================
   SAIR
===================================================== */

function sair() {

    localStorage.removeItem(
        "mac_perfil"
    );


    window.location.href =
        "login.html";

}