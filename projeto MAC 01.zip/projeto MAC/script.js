const btnmenu = document.getElementById('btn-menu');
const menulateral = document.querySelector('.menu-lateral');

btnmenu.addEventListener('click', function(){
    menulateral.classList.toggle('expandir')
})



